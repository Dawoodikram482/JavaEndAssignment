# Java End Assignment 

## Login Details for App
#### Password for Sales user
Username: Dawood  
Password: Ikram&123
 #### Password for Manager
Username: Parranasian   
Password: Parrapeero&123

