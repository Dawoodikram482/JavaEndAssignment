package com.example.javaendassignment.Models;

public enum Role {
  Sales, Manager
}
