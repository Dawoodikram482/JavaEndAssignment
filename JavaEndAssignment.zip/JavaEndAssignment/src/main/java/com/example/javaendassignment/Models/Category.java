package com.example.javaendassignment.Models;

public enum Category {
  Guitar, Piano, Drum
}
